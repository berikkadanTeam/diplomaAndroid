package com.login.mobi.loginapp;

import android.arch.persistence.room.Room;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;

import com.login.mobi.loginapp.Database.AppDatabase;
import com.login.mobi.loginapp.Database.UserDatabase;
import com.login.mobi.loginapp.Models.Book;
import com.login.mobi.loginapp.Models.Restaurant;
import com.squareup.picasso.Picasso;

import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;

public class DetailsActivity extends AppCompatActivity {

    ArrayList<String> timeList = new ArrayList<>(Arrays.asList("12:00-14:00", "14:00-16:00",
            "16:00-18:00", "18:00-20:00"));

    ArrayList<Integer> tableList = new ArrayList<>();

    TextView name;
    TextView description;
    TextView address;
    TextView booked;
    ImageView schema;
    ImageView iv;
    Button book;
    Spinner table;
    Spinner time;

    View toolbar;

    TextView title;
    ImageView back;

    int tableId;
    String bookTime;

    int restaurantId = -1;

    Restaurant restaurant;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_details);

        final UserDatabase db = ((MyApp) getApplicationContext()).database;

        name = findViewById(R.id.name);
        description = findViewById(R.id.description);
        address = findViewById(R.id.address);
        schema = findViewById(R.id.schema);
        booked = findViewById(R.id.booked);
        iv = findViewById(R.id.iv);
        book = findViewById(R.id.book);
        table = findViewById(R.id.table);
        time = findViewById(R.id.time);

        toolbar = findViewById(R.id.toolbar);

        title = toolbar.findViewById(R.id.title);
        back = toolbar.findViewById(R.id.backbutton);

        title.setText("Restaurant details");
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();
            }
        });

        time.setAdapter(new ArrayAdapter<>(this, R.layout.support_simple_spinner_dropdown_item, timeList));

        table.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                tableId = tableList.get(i);
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });

        time.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                bookTime = timeList.get(i);
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });


        book.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                SharedPreferences pref = getSharedPreferences("MainActivity", Context.MODE_PRIVATE);
                if (pref.getInt("userId", -1) != -1){
                    if (db.bookDAO().getByTableId(tableId).size() != 0){
                        AlertDialog dialog = new AlertDialog.Builder(getBaseContext())
                                .setTitle("Table is already reserved!!!")
                                .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialogInterface, int i) {
                                        dialogInterface.dismiss();
                                    }
                                }).create();
                        dialog.show();
                    }else{
                        Book book = new Book(pref.getInt("userId", -1), tableId, bookTime);
                        //                    db.bookDAO().insert(book);
//                        finish();
                    }

                    Log.d("TAG","book " + db.bookDAO().getAll());
                }
            }
        });

        Intent intent = getIntent();

        restaurantId = intent.getIntExtra("id", -1);

        Log.d("TAG", "id " + restaurantId);

        if (restaurantId != -1){
            restaurant = db.restaurantDAO().getById(restaurantId).get(0);

            tableList.clear();

            for (int i = 0; i < db.tableDAO().getAllByRestaurantId(restaurant.id).size(); i++){
                tableList.add(i + 1);
            }

            table.setAdapter(new ArrayAdapter<>(this, R.layout.support_simple_spinner_dropdown_item, tableList));

            booked.setText(restaurant.bookCount + " times");
            Picasso.get().load(restaurant.imageUrl).into(iv);
            name.setText(restaurant.name);
            description.setText(restaurant.description);
            address.setText(restaurant.address);
            Picasso.get().load(restaurant.schema).into(schema);
        }
    }
}
